// Number of fixed endpoints
#define FIXED_ENDPOINT_COUNT (3)
